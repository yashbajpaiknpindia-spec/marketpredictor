from __future__ import annotations
"""MarketPredictor UltraScalp v2

Fast, strategy-free event scalper research engine.

v2 changes vs v1
----------------
* Removes the learned probability/expected-return model from the trigger path.
* Uses a causal continuation-quality score built from raw 1-minute behavior.
* Adds impulse freshness, candle efficiency, relative-strength confirmation,
  volume acceleration, exhaustion avoidance and anti-chase gates.
* Uses adaptive stop/target ranges rather than a single fixed target/stop.
* Adds very fast thesis-failure and profit-lock exits.
* Preserves next-minute-open execution and conservative stop-first ambiguity.

Research only. No live order placement.
"""

from dataclasses import dataclass, asdict
from typing import Dict, Optional, Tuple
import math
import numpy as np
import pandas as pd


@dataclass(frozen=True)
class UltraScalpConfig:
    # Economics / execution. Base costs are kept aligned with MarketPredictor research.
    mandatory_cost_pct: float = 0.1063
    execution_slippage_pct: float = 0.03
    # Exit geometry: dynamic around these anchors.
    min_target_pct: float = 0.25
    max_target_pct: float = 0.40
    min_stop_pct: float = 0.07
    max_stop_pct: float = 0.14
    target_rr: float = 1.9
    # Fast lifecycle.
    max_hold_bars: int = 4
    thesis_failure_bars: int = 1
    min_fav_before_hold: float = 0.04
    adverse_close_exit_pct: float = 0.025
    stall_bars: int = 2
    stall_min_fav_pct: float = 0.08
    stall_min_progress_pct: float = 0.03
    profit_lock_trigger: float = 0.15
    profit_lock_floor: float = 0.16
    # Trigger quality.
    min_score: float = 5.75
    volume_z_min: float = 1.20
    volume_z_max: float = 8.0
    range_z_min: float = 1.00
    range_z_max: float = 5.0
    min_abs_ret1_pct: float = 0.07
    max_abs_ret1_pct: float = 0.42
    min_abs_ret3_pct: float = 0.12
    max_abs_ret3_pct: float = 0.55
    min_abs_rel1_pct: float = 0.05
    min_abs_rel3_pct: float = 0.06
    min_body_efficiency: float = 0.50
    min_close_loc: float = 0.85
    max_chase_from_vwap_pct: float = 1.6
    max_spike_range_pct: float = 0.75
    cooldown_bars: int = 5
    min_price: float = 50.0
    # Time filters: avoid the least useful midday micro-noise by default.
    start_minute: int = 9 * 60 + 25
    end_minute: int = 15 * 60 + 15


FEATURES = [
    "ret1_pct", "ret2_pct", "ret3_pct", "prev_ret1_pct", "same_dir_2bar", "accel_pct", "range_pct",
    "body_pct", "body_efficiency", "close_loc", "upper_wick_pct", "lower_wick_pct",
    "vol_z20", "vol_accel", "range_z20", "break_up10", "break_dn10",
    "dist_hi10_pct", "dist_lo10_pct", "dist_vwap_pct", "mkt_ret1_pct", "mkt_ret3_pct",
    "rel_ret1_pct", "rel_ret3_pct", "vix_ret1_pct", "sector_ret1_pct", "sector_rel1_pct",
    "tod_sin", "tod_cos", "gap_pct",
]


def add_features(stock: pd.DataFrame, market: Optional[pd.DataFrame] = None,
                 vix: Optional[pd.DataFrame] = None,
                 sector: Optional[pd.DataFrame] = None) -> pd.DataFrame:
    df = stock.copy().sort_index()
    if not isinstance(df.index, pd.DatetimeIndex):
        raise ValueError("stock index must be a DatetimeIndex")
    for c in ("open", "high", "low", "close", "volume"):
        if c not in df:
            raise ValueError(f"missing column: {c}")
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["open", "high", "low", "close"])

    px, op, hi, lo = df["close"], df["open"], df["high"], df["low"]
    rng = (hi - lo).clip(lower=0)
    body = px - op
    df["ret1_pct"] = px.pct_change(1) * 100
    df["ret2_pct"] = px.pct_change(2) * 100
    df["ret3_pct"] = px.pct_change(3) * 100
    df["prev_ret1_pct"] = df["ret1_pct"].shift(1)
    df["same_dir_2bar"] = (np.sign(df["ret1_pct"]) == np.sign(df["prev_ret1_pct"])) .astype(float)
    df["accel_pct"] = df["ret1_pct"] - df["ret2_pct"].div(2)
    df["range_pct"] = rng.div(px.replace(0, np.nan)) * 100
    df["body_pct"] = body.div(px.replace(0, np.nan)) * 100
    df["body_efficiency"] = body.abs().div(rng.replace(0, np.nan)).clip(0, 1)
    df["close_loc"] = ((px - lo) / rng.replace(0, np.nan)).clip(0, 1)
    df["upper_wick_pct"] = ((hi - pd.concat([op, px], axis=1).max(axis=1)) / px.replace(0, np.nan)) * 100
    df["lower_wick_pct"] = ((pd.concat([op, px], axis=1).min(axis=1) - lo) / px.replace(0, np.nan)) * 100

    vol = df["volume"].fillna(0.0)
    vol_med = vol.rolling(20, min_periods=10).median()
    vol_mad = (vol - vol_med).abs().rolling(20, min_periods=10).median()
    df["vol_z20"] = (vol - vol_med) / (1.4826 * vol_mad.replace(0, np.nan))
    prev3_med = vol.shift(1).rolling(3, min_periods=3).median()
    df["vol_accel"] = vol / prev3_med.replace(0, np.nan)

    rng_med = df["range_pct"].rolling(20, min_periods=10).median()
    rng_mad = (df["range_pct"] - rng_med).abs().rolling(20, min_periods=10).median()
    df["range_z20"] = (df["range_pct"] - rng_med) / (1.4826 * rng_mad.replace(0, np.nan))

    prev_hi10 = hi.shift(1).rolling(10, min_periods=10).max()
    prev_lo10 = lo.shift(1).rolling(10, min_periods=10).min()
    df["break_up10"] = (px > prev_hi10 * 1.0002).astype(float)
    df["break_dn10"] = (px < prev_lo10 * 0.9998).astype(float)
    df["dist_hi10_pct"] = (px / prev_hi10 - 1) * 100
    df["dist_lo10_pct"] = (px / prev_lo10 - 1) * 100

    pv = (px * vol).cumsum()
    vv = vol.cumsum().replace(0, np.nan)
    df["dist_vwap_pct"] = (px / (pv / vv) - 1) * 100

    mkt = _align_context(df.index, market, "mkt")
    if mkt is not None:
        df = df.join(mkt, how="left")
    else:
        df["mkt_ret1_pct"] = 0.0; df["mkt_ret3_pct"] = 0.0
    df["rel_ret1_pct"] = df["ret1_pct"] - df["mkt_ret1_pct"]
    df["rel_ret3_pct"] = df["ret3_pct"] - df["mkt_ret3_pct"]

    vx = _align_context(df.index, vix, "vix")
    df = df.join(vx, how="left") if vx is not None else df.assign(vix_ret1_pct=0.0)
    sx = _align_context(df.index, sector, "sector")
    df = df.join(sx, how="left") if sx is not None else df.assign(sector_ret1_pct=0.0)
    df["sector_rel1_pct"] = df["ret1_pct"] - df["sector_ret1_pct"]

    minute = df.index.hour * 60 + df.index.minute
    x = (minute - (9 * 60 + 15)) / 375.0 * math.pi
    df["tod_sin"] = np.sin(x); df["tod_cos"] = np.cos(x)

    # Correct daily gap: session open vs immediately prior trading day's close when available.
    sessions = df.index.normalize()
    first_open = df.groupby(sessions)["open"].transform("first")
    prev_close_by_day = df.groupby(sessions)["close"].transform("first").shift(1)
    df["gap_pct"] = ((first_open / prev_close_by_day) - 1) * 100
    return df.replace([np.inf, -np.inf], np.nan)


def _align_context(index: pd.DatetimeIndex, context: Optional[pd.DataFrame], prefix: str) -> Optional[pd.DataFrame]:
    if context is None or context.empty:
        return None
    c = context.copy().sort_index()
    if not isinstance(c.index, pd.DatetimeIndex):
        raise ValueError("context index must be DatetimeIndex")
    c = c[~c.index.duplicated(keep="last")]
    if "close" not in c:
        return None
    close = pd.to_numeric(c["close"], errors="coerce")
    out = pd.DataFrame(index=c.index)
    out[f"{prefix}_ret1_pct"] = close.pct_change() * 100
    if prefix != "vix" and prefix != "sector":
        out[f"{prefix}_ret3_pct"] = close.pct_change(3) * 100
    return out.reindex(index, method="ffill")


def event_score(row: pd.Series, cfg: UltraScalpConfig) -> Tuple[float, int, Dict[str, float]]:
    """Causal continuation-quality score. No fitted model and no future information."""
    r1 = float(row.get("ret1_pct", 0) or 0); r3 = float(row.get("ret3_pct", 0) or 0)
    acc = float(row.get("accel_pct", 0) or 0); vz = float(row.get("vol_z20", 0) or 0)
    va = float(row.get("vol_accel", 1) or 1); rz = float(row.get("range_z20", 0) or 0)
    loc = float(row.get("close_loc", .5) or .5); eff = float(row.get("body_efficiency", 0) or 0)
    rel1 = float(row.get("rel_ret1_pct", 0) or 0); rel3 = float(row.get("rel_ret3_pct", 0) or 0)
    bu = float(row.get("break_up10", 0) or 0); bd = float(row.get("break_dn10", 0) or 0)
    dv = float(row.get("dist_vwap_pct", 0) or 0)
    m1 = float(row.get("mkt_ret1_pct", 0) or 0); sec = float(row.get("sector_ret1_pct", 0) or 0)

    def clamp(x, lo=0.0, hi=1.0): return float(min(hi, max(lo, x)))
    # Strength rewards smooth continuation but penalizes exhaustion/chasing.
    long = 0.0; short = 0.0
    long += 1.4 * clamp((r1 - cfg.min_abs_ret1_pct) / 0.25)
    long += 1.1 * clamp((r3 - cfg.min_abs_ret3_pct) / 0.40)
    long += 1.0 * clamp(acc / 0.12)
    long += 1.2 * clamp((vz - cfg.volume_z_min) / 5.0)
    long += 0.7 * clamp((va - 1.0) / 2.0)
    long += 1.0 * clamp((rz - cfg.range_z_min) / 3.5)
    long += 0.9 * clamp((loc - cfg.min_close_loc) / 0.22)
    long += 0.8 * clamp((eff - cfg.min_body_efficiency) / 0.45)
    long += 0.5 if float(row.get("same_dir_2bar",0) or 0)>0.5 else 0.0
    long += 0.9 if bu > 0.5 else 0.0
    long += 1.0 * clamp((rel1 - cfg.min_abs_rel1_pct) / 0.18)
    long += 0.8 * clamp((rel3 - cfg.min_abs_rel3_pct) / 0.30)
    long += 0.35 if (m1 > 0 or sec > 0) else 0.0
    # Freshness/chase penalties.
    if abs(r1) > 0.42: long -= 0.9
    if abs(r3) > 0.55: long -= 0.7
    if abs(dv) > cfg.max_chase_from_vwap_pct: long -= 0.8
    if vz > cfg.volume_z_max or rz > cfg.range_z_max: long -= 1.0

    short += 1.4 * clamp((-r1 - cfg.min_abs_ret1_pct) / 0.25)
    short += 1.1 * clamp((-r3 - cfg.min_abs_ret3_pct) / 0.40)
    short += 1.0 * clamp((-acc) / 0.12)
    short += 1.2 * clamp((vz - cfg.volume_z_min) / 5.0)
    short += 0.7 * clamp((va - 1.0) / 2.0)
    short += 1.0 * clamp((rz - cfg.range_z_min) / 3.5)
    short += 0.9 * clamp((0.22 - loc) / 0.22)
    short += 0.8 * clamp((eff - cfg.min_body_efficiency) / 0.45)
    short += 0.5 if float(row.get("same_dir_2bar",0) or 0)>0.5 else 0.0
    short += 0.9 if bd > 0.5 else 0.0
    short += 1.0 * clamp((-rel1 - cfg.min_abs_rel1_pct) / 0.18)
    short += 0.8 * clamp((-rel3 - cfg.min_abs_rel3_pct) / 0.30)
    short += 0.35 if (m1 < 0 or sec < 0) else 0.0
    if abs(r1) > 0.42: short -= 0.9
    if abs(r3) > 0.55: short -= 0.7
    if abs(dv) > cfg.max_chase_from_vwap_pct: short -= 0.8
    if vz > cfg.volume_z_max or rz > cfg.range_z_max: short -= 1.0

    if long >= short:
        return long, 1, {"long_score": long, "short_score": short}
    return short, -1, {"long_score": long, "short_score": short}


def build_trigger_table(features: pd.DataFrame, cfg: UltraScalpConfig) -> pd.DataFrame:
    rows=[]; last_signal=-10_000
    for i,(ts,row) in enumerate(features.iterrows()):
        if i < 25: continue
        minute = ts.hour*60 + ts.minute
        if minute < cfg.start_minute or minute > cfg.end_minute: continue
        px=float(row.get("close",np.nan) or np.nan)
        if not np.isfinite(px) or px<cfg.min_price: continue
        if i-last_signal < cfg.cooldown_bars: continue
        r1=float(row.get("ret1_pct",0) or 0); r3=float(row.get("ret3_pct",0) or 0)
        vz=float(row.get("vol_z20",np.nan)); rz=float(row.get("range_z20",np.nan)); va=float(row.get("vol_accel",np.nan))
        if not (np.isfinite(vz) and np.isfinite(rz) and np.isfinite(va)): continue
        if vz<cfg.volume_z_min or vz>cfg.volume_z_max or rz<cfg.range_z_min or rz>cfg.range_z_max: continue
        if not (cfg.min_abs_ret1_pct <= abs(r1) <= cfg.max_abs_ret1_pct): continue
        if not (cfg.min_abs_ret3_pct <= abs(r3) <= cfg.max_abs_ret3_pct): continue
        if float(row.get("body_efficiency",0) or 0) < cfg.min_body_efficiency: continue
        score,direction,diag=event_score(row,cfg)
        if score < cfg.min_score: continue
        loc=float(row.get("close_loc",.5) or .5)
        if direction==1 and loc<cfg.min_close_loc: continue
        if direction==-1 and loc>(1-cfg.min_close_loc): continue
        rel1=float(row.get("rel_ret1_pct",0) or 0); rel3=float(row.get("rel_ret3_pct",0) or 0)
        if direction==1 and not (rel1>=cfg.min_abs_rel1_pct and rel3>=cfg.min_abs_rel3_pct): continue
        if direction==-1 and not (rel1<=-cfg.min_abs_rel1_pct and rel3<=-cfg.min_abs_rel3_pct): continue
        # Fresh breakout continuation: either a current break or a close sitting just under the prior extreme with strong confirmation.
        dhi=float(row.get("dist_hi10_pct",0) or 0); dlo=float(row.get("dist_lo10_pct",0) or 0)
        if direction==1 and not ((float(row.get("break_up10",0) or 0)>0.5) or (-0.08<=dhi<=0.22)): continue
        if direction==-1 and not ((float(row.get("break_dn10",0) or 0)>0.5) or (-0.22<=dlo<=0.08)): continue
        rows.append({"ts":ts,"direction":direction,"event_score":score,**diag})
        last_signal=i
    return pd.DataFrame(rows)


def _adaptive_exit_levels(row: pd.Series, cfg: UltraScalpConfig) -> Tuple[float,float]:
    # Adapt to current bar noise without letting risk explode.
    rz=float(row.get("range_pct",0.10) or 0.10)
    stop=float(np.clip(rz*0.45, cfg.min_stop_pct, cfg.max_stop_pct))
    target=float(np.clip(max(cfg.min_target_pct, stop*cfg.target_rr + 0.11), cfg.min_target_pct, cfg.max_target_pct))
    return target, stop


def label_fast_trade(df: pd.DataFrame, i:int, direction:int, cfg:UltraScalpConfig)->Dict[str,float]:
    if i+1>=len(df): return {"outcome_net_pct":np.nan,"gross_pct":np.nan,"exit_bar":np.nan,"exit_reason":"NO_NEXT_BAR"}
    entry=float(df["open"].iloc[i+1]); target_pct, stop_pct=_adaptive_exit_levels(df.iloc[i],cfg)
    if not np.isfinite(entry) or entry<=0: return {"outcome_net_pct":np.nan,"gross_pct":np.nan,"exit_bar":np.nan,"exit_reason":"BAD_ENTRY"}
    target=entry*(1+direction*target_pct/100); stop=entry*(1-direction*stop_pct/100); best_fav=0.0
    first_adverse=0.0
    cost=cfg.mandatory_cost_pct+cfg.execution_slippage_pct
    for j in range(i+1,min(len(df),i+1+cfg.max_hold_bars)):
        h=float(df["high"].iloc[j]); l=float(df["low"].iloc[j]); c=float(df["close"].iloc[j])
        if direction==1:
            fav=(h/entry-1)*100; prog=(c/entry-1)*100; adv=(l/entry-1)*100
            hit_stop=l<=stop; hit_target=h>=target
        else:
            fav=(entry/l-1)*100 if l>0 else 0.0; prog=(entry/c-1)*100 if c>0 else -999; adv=(entry/h-1)*100 if h>0 else 0.0
            hit_stop=h>=stop; hit_target=l<=target
        best_fav=max(best_fav,fav); first_adverse=min(first_adverse,adv)
        if hit_stop and hit_target: return {"outcome_net_pct":-stop_pct-cost,"gross_pct":-stop_pct,"best_fav_pct":best_fav,"exit_bar":j,"exit_reason":"STOP_SAME_BAR","target_pct":target_pct,"stop_pct":stop_pct}
        if hit_stop: return {"outcome_net_pct":-stop_pct-cost,"gross_pct":-stop_pct,"best_fav_pct":best_fav,"exit_bar":j,"exit_reason":"HARD_STOP","target_pct":target_pct,"stop_pct":stop_pct}
        if hit_target: return {"outcome_net_pct":target_pct-cost,"gross_pct":target_pct,"best_fav_pct":best_fav,"exit_bar":j,"exit_reason":"TARGET","target_pct":target_pct,"stop_pct":stop_pct}

        age=j-i
        # Ultra-fast failure: the first completed bar closes meaningfully against entry.
        if age >= cfg.thesis_failure_bars and prog <= -cfg.adverse_close_exit_pct:
            return {"outcome_net_pct":prog-cost,"gross_pct":prog,"best_fav_pct":best_fav,"exit_bar":j,"exit_reason":"ADVERSE_CLOSE","target_pct":target_pct,"stop_pct":stop_pct}
        # Stall failure: an impulse that cannot produce enough follow-through is abandoned.
        if age >= cfg.stall_bars and best_fav < cfg.stall_min_fav_pct and prog < cfg.stall_min_progress_pct:
            return {"outcome_net_pct":prog-cost,"gross_pct":prog,"best_fav_pct":best_fav,"exit_bar":j,"exit_reason":"STALL","target_pct":target_pct,"stop_pct":stop_pct}
        # Once profitable enough, protect a portion of the move.
        if best_fav>=cfg.profit_lock_trigger and prog<cfg.profit_lock_floor:
            return {"outcome_net_pct":prog-cost,"gross_pct":prog,"best_fav_pct":best_fav,"exit_bar":j,"exit_reason":"PROFIT_LOCK","target_pct":target_pct,"stop_pct":stop_pct}
        if j==min(len(df),i+1+cfg.max_hold_bars)-1:
            return {"outcome_net_pct":prog-cost,"gross_pct":prog,"best_fav_pct":best_fav,"exit_bar":j,"exit_reason":"TIMEOUT","target_pct":target_pct,"stop_pct":stop_pct}
    return {"outcome_net_pct":np.nan,"gross_pct":np.nan,"best_fav_pct":best_fav,"exit_bar":np.nan,"exit_reason":"UNRESOLVED","target_pct":target_pct,"stop_pct":stop_pct}


def prepare_event_frame(features:pd.DataFrame,cfg:UltraScalpConfig)->pd.DataFrame:
    tr=build_trigger_table(features,cfg)
    if tr.empty:return tr
    idx_lookup={ts:i for i,ts in enumerate(features.index)}; recs=[]
    for rec in tr.to_dict("records"):
        i=idx_lookup[rec["ts"]]; base=features.loc[rec["ts"],FEATURES].to_dict(); base.update(rec); base.update(label_fast_trade(features,i,int(rec["direction"]),cfg)); recs.append(base)
    return pd.DataFrame(recs)


def serialize_config(cfg:UltraScalpConfig)->Dict[str,object]: return asdict(cfg)

class UltraScalpRuntime:
    """Bounded-memory incremental runtime for one symbol; no retraining required."""
    def __init__(self, ticker: str, cfg: UltraScalpConfig = UltraScalpConfig()):
        from collections import deque
        self.ticker=ticker; self.cfg=cfg
        self.opens=deque(maxlen=64); self.highs=deque(maxlen=64); self.lows=deque(maxlen=64); self.closes=deque(maxlen=64); self.volumes=deque(maxlen=64)
        self.bar_count=0; self.last_signal=-10_000; self.day_pv=0.0; self.day_v=0.0
    @staticmethod
    def _median_mad(a):
        a=np.asarray(a,dtype=float)
        med=float(np.median(a)) if a.size else 0.0; mad=float(np.median(np.abs(a-med))) if a.size else 0.0
        return med,mad
    def reset_session(self):
        self.opens.clear(); self.highs.clear(); self.lows.clear(); self.closes.clear(); self.volumes.clear(); self.bar_count=0; self.last_signal=-10_000; self.day_pv=0.0; self.day_v=0.0
    def update(self,timestamp,open_,high,low,close,volume,market_ret1_pct=0.0,market_ret3_pct=0.0,vix_ret1_pct=0.0,sector_ret1_pct=0.0):
        self.bar_count+=1
        self.opens.append(float(open_)); self.highs.append(float(high)); self.lows.append(float(low)); self.closes.append(float(close)); self.volumes.append(max(float(volume),0.0))
        self.day_pv+=float(close)*max(float(volume),0.0); self.day_v+=max(float(volume),0.0)
        if len(self.closes)<25: return None
        px=self.closes[-1]; p1=self.closes[-2]; p2=self.closes[-3]; p3=self.closes[-4]
        r1=(px/p1-1)*100 if p1 else 0.0; r2=(px/p2-1)*100 if p2 else 0.0; r3=(px/p3-1)*100 if p3 else 0.0
        prev_r1=(p1/p2-1)*100 if p2 else 0.0
        rng=max(self.highs[-1]-self.lows[-1],0.0); range_pct=rng/px*100 if px else 0.0
        body_pct=(px-self.opens[-1])/px*100 if px else 0.0; eff=abs(px-self.opens[-1])/rng if rng else 0.0
        loc=(px-self.lows[-1])/rng if rng else .5
        upper=(self.highs[-1]-max(self.opens[-1],px))/px*100 if px else 0.0; lower=(min(self.opens[-1],px)-self.lows[-1])/px*100 if px else 0.0
        vols=np.asarray(self.volumes[-20:],float); vm,vmad=self._median_mad(vols); vz=(self.volumes[-1]-vm)/(1.4826*vmad) if vmad>0 else 0.0
        prev3=float(np.median(self.volumes[-4:-1])) if len(self.volumes)>=4 else 0.0; va=self.volumes[-1]/prev3 if prev3>0 else 0.0
        ranges=np.asarray([max(h-l,0)/c*100 if c else 0 for h,l,c in zip(self.highs[-20:],self.lows[-20:],self.closes[-20:])],float); rm,rmad=self._median_mad(ranges); rz=(range_pct-rm)/(1.4826*rmad) if rmad>0 else 0.0
        ph=max(list(self.highs)[-11:-1]); pl=min(list(self.lows)[-11:-1]); bu=float(px>ph*1.0002); bd=float(px<pl*0.9998)
        vwap=self.day_pv/self.day_v if self.day_v>0 else px; dv=(px/vwap-1)*100 if vwap else 0.0
        row=pd.Series({
            'ret1_pct':r1,'ret2_pct':r2,'ret3_pct':r3,'prev_ret1_pct':prev_r1,'same_dir_2bar':float(np.sign(r1)==np.sign(prev_r1)),'accel_pct':r1-r2/2,'range_pct':range_pct,'body_pct':body_pct,'body_efficiency':eff,'close_loc':loc,'upper_wick_pct':upper,'lower_wick_pct':lower,'vol_z20':vz,'vol_accel':va,'range_z20':rz,'break_up10':bu,'break_dn10':bd,'dist_hi10_pct':(px/ph-1)*100,'dist_lo10_pct':(px/pl-1)*100,'dist_vwap_pct':dv,'mkt_ret1_pct':market_ret1_pct,'mkt_ret3_pct':market_ret3_pct,'rel_ret1_pct':r1-market_ret1_pct,'rel_ret3_pct':r3-market_ret3_pct,'vix_ret1_pct':vix_ret1_pct,'sector_ret1_pct':sector_ret1_pct,'sector_rel1_pct':r1-sector_ret1_pct,'tod_sin':0.0,'tod_cos':1.0,'gap_pct':0.0})
        minute=timestamp.hour*60+timestamp.minute if hasattr(timestamp,'hour') else 0
        if minute<self.cfg.start_minute or minute>self.cfg.end_minute or px<self.cfg.min_price or self.bar_count-self.last_signal<self.cfg.cooldown_bars: return None
        if not (self.cfg.volume_z_min<=vz<=self.cfg.volume_z_max and self.cfg.range_z_min<=rz<=self.cfg.range_z_max): return None
        if not (self.cfg.min_abs_ret1_pct<=abs(r1)<=self.cfg.max_abs_ret1_pct and self.cfg.min_abs_ret3_pct<=abs(r3)<=self.cfg.max_abs_ret3_pct): return None
        if eff<self.cfg.min_body_efficiency: return None
        score,direction,diag=event_score(row,self.cfg)
        if score<self.cfg.min_score: return None
        if direction==1 and loc<self.cfg.min_close_loc: return None
        if direction==-1 and loc>(1-self.cfg.min_close_loc): return None
        if direction==1 and not (row.rel_ret1_pct>=self.cfg.min_abs_rel1_pct and row.rel_ret3_pct>=self.cfg.min_abs_rel3_pct): return None
        if direction==-1 and not (row.rel_ret1_pct<=-self.cfg.min_abs_rel1_pct and row.rel_ret3_pct<=-self.cfg.min_abs_rel3_pct): return None
        if direction==1 and not (bu>0.5 or -0.08<=row.dist_hi10_pct<=0.22): return None
        if direction==-1 and not (bd>0.5 or -0.22<=row.dist_lo10_pct<=0.08): return None
        self.last_signal=self.bar_count
        return {'ticker':self.ticker,'timestamp':timestamp,'direction':'LONG' if direction>0 else 'SHORT','event_score':round(score,4),'last_price':px,'volume_z':round(vz,3),'range_z':round(rz,3),'diagnostics':diag}
