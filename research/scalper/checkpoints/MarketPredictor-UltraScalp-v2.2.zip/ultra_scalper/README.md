# MarketPredictor UltraScalp v2.2

Research-only, strategy-free, event-driven 1-minute scalper.

## What changed from v1
- Removed the learned probability/edge model from the trigger path.
- Detects fresh continuation events from raw price/volume behavior.
- Adds candle efficiency, 2-bar directional persistence, relative-strength confirmation and anti-chase caps.
- Uses adaptive target/stop geometry.
- Adds adverse-close and stall exits so a failed scalp is killed quickly.
- Adds profit-lock only after the move is materially above the all-in cost hurdle.
- Includes a bounded-memory incremental runtime for one-minute paper/live-style scoring.

## Diagnostic result: 2026-09-25
Same real 1-minute archive, top-20-volume-stock diagnostic universe.

- v1: 351 triggered events, average net about -0.1345%.
- v2: 46 triggered events, average net about -0.1297%.
- v2.1: 12 triggered events, average net about -0.1111%.
- v2.2: 12 triggered events, average net about -0.1061%.

The reduction is an engineering/model-quality improvement, but **this is still negative on the test session and is not evidence of a live edge**. The next gate is chronological weekly out-of-sample testing without retuning to the test week.

## Economics
The current research cost assumptions retain MarketPredictor's existing mandatory charge model plus execution slippage. A scalp must generate enough gross movement to overcome friction; high trade count or high raw trigger frequency is not considered success.

## Execution assumptions
- Next-minute-open entry.
- Conservative stop-first handling when OHLC cannot reveal intrabar ordering.
- LONG/SHORT symmetry.
- Hard protection, thesis-failure, stall and profit-lock exits.

This bundle places no real orders.
