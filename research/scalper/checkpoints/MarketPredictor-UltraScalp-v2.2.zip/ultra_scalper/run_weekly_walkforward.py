from __future__ import annotations

import argparse
import io
import json
import zipfile
from collections import defaultdict
from pathlib import Path

import numpy as np
import pandas as pd

from ultra_scalper_v1 import UltraScalpConfig, UltraScalpEdgeModel, add_features, prepare_training_frame



def read_csv(zf: zipfile.ZipFile, name: str) -> pd.DataFrame:
    with zf.open(name) as fh:
        df = pd.read_csv(fh)
    time_col = "epoch" if "epoch" in df.columns else ("timestamp" if "timestamp" in df.columns else None)
    if time_col is None:
        raise ValueError(f"no timestamp column in {name}")
    idx = pd.to_datetime(df[time_col], unit="s", utc=True).dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
    df = df.drop(columns=[time_col])
    df = df.loc[~idx.duplicated(keep="last")].copy()
    idx = idx[~idx.duplicated(keep="last")]
    df.index = idx
    return df


def list_stock_files(zf: zipfile.ZipFile):
    out = []
    for n in zf.namelist():
        if not n.startswith("historical_data/") or not n.endswith(".csv"):
            continue
        parts = n.split("/")
        if len(parts) == 3:
            out.append(n)
    return sorted(out)


def group_days(files):
    days = defaultdict(list)
    for f in files:
        day = f.split("/")[1]
        days[day].append(f)
    return {d: sorted(v) for d, v in days.items()}


def load_context(zf, path):
    try:
        df = read_csv(zf, path)
        return df
    except Exception:
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--zip", required=True)
    ap.add_argument("--out", default="ultrascalp_weekly_results.csv")
    args = ap.parse_args()
    cfg = UltraScalpConfig()
    rows = []
    with zipfile.ZipFile(args.zip) as zf:
        files = list_stock_files(zf)
        days = group_days(files)
        day_list = sorted(days)
        week_numbers = pd.to_datetime(day_list).isocalendar().week.astype(int)
        weeks = sorted(set(zip(week_numbers.tolist(), [d[:4] for d in day_list])))

        mkt = load_context(zf, "market/NIFTY.csv")
        vix = load_context(zf, "market/INDIA_VIX.csv")
        # sector is intentionally optional; stock files may not have a stable mapping.
        sectors = None

        # Preload stock files by day for the rolling test. This is a research harness, not live execution.
        daily = defaultdict(dict)
        for f in files:
            day = f.split("/")[1]
            ticker = Path(f).stem
            daily[day][ticker] = read_csv(zf, f)

        day_to_week = {d: (int(pd.Timestamp(d).isocalendar().year), int(pd.Timestamp(d).isocalendar().week)) for d in day_list}
        ordered_weeks = sorted(set(day_to_week.values()))

        for widx, week in enumerate(ordered_weeks):
            test_days = [d for d in day_list if day_to_week[d] == week]
            train_days = [d for d in day_list if day_to_week[d] < week]
            if not train_days:
                continue
            print(f"WEEK {week}: train={len(train_days)} days test={len(test_days)} days", flush=True)

            train_rows = []
            test_rows = []
            # Recompute per ticker; only compact trigger rows are retained.
            tickers = sorted(set().union(*(daily[d].keys() for d in test_days)))
            for ticker in tickers:
                hist_frames = [daily[d][ticker] for d in train_days[-10:] if ticker in daily[d]]
                if len(hist_frames) < 3:
                    continue
                hist = pd.concat(hist_frames).sort_index()
                # train frame uses the complete pre-test history available to this ticker
                feat_train = add_features(hist, mkt, vix, sectors)
                if len(feat_train) > 30:
                    tr = prepare_training_frame(feat_train, cfg)
                    if not tr.empty:
                        train_rows.append(tr)
                test_frames = [daily[d][ticker] for d in test_days if ticker in daily[d]]
                if test_frames:
                    test = pd.concat(test_frames).sort_index()
                    # warm up with recent history, but labels only fall in test days
                    warm = hist_frames[-3:]
                    combo = pd.concat(warm + [test]).sort_index().iloc[-(len(test)+400):]
                    feat_test = add_features(combo, mkt, vix, sectors)
                    tr_end = test.index[0]
                    feat_test = feat_test.loc[feat_test.index >= tr_end]
                    if not feat_test.empty:
                        te = prepare_training_frame(feat_test, cfg)
                        if not te.empty:
                            test_rows.append(te)

            if not train_rows or not test_rows:
                rows.append({"week": f"{week[0]}-W{week[1]:02d}", "trades": 0, "status": "NO_TRIGGER_DATA"})
                continue
            train = pd.concat(train_rows, ignore_index=True)
            test = pd.concat(test_rows, ignore_index=True)
            if len(train) < cfg.min_training_rows:
                rows.append({"week": f"{week[0]}-W{week[1]:02d}", "trades": 0, "status": f"TRAIN_ROWS_{len(train)}"})
                continue

            model = UltraScalpEdgeModel(cfg).fit(train, train["outcome_net_pct"])
            test["edge_score_pct"] = model.score(test)
            selected = test[test["edge_score_pct"] >= cfg.min_expected_net_pct].copy()
            wins = int((selected["outcome_net_pct"] > 0).sum())
            losses = int((selected["outcome_net_pct"] <= 0).sum())
            net = float(selected["outcome_net_pct"].sum()) if len(selected) else 0.0
            gross = float(selected["gross_pct"].sum()) if len(selected) else 0.0
            target_hits = int((selected["exit_reason"] == "TARGET").sum())
            pf = None
            gain = selected.loc[selected["outcome_net_pct"] > 0, "outcome_net_pct"].sum()
            loss = -selected.loc[selected["outcome_net_pct"] < 0, "outcome_net_pct"].sum()
            if loss > 0:
                pf = float(gain / loss)
            rows.append({
                "week": f"{week[0]}-W{week[1]:02d}",
                "train_triggers": len(train),
                "test_triggers": len(test),
                "selected_trades": len(selected),
                "wins": wins,
                "losses": losses,
                "win_rate_pct": round(wins / len(selected) * 100, 2) if len(selected) else 0,
                "target_hit_rate_pct": round(target_hits / len(selected) * 100, 2) if len(selected) else 0,
                "gross_pnl_pct_sum": round(gross, 4),
                "net_pnl_pct_sum": round(net, 4),
                "avg_net_pct": round(net / len(selected), 5) if len(selected) else 0,
                "profit_factor": round(pf, 3) if pf is not None else None,
                "status": "PASSING" if net > 0 else "NEGATIVE",
            })
            test.to_csv(Path(args.out).with_name(Path(args.out).stem + f"_{week[0]}W{week[1]:02d}_trades.csv"), index=False)

    pd.DataFrame(rows).to_csv(args.out, index=False)
    print(json.dumps(rows, indent=2))


if __name__ == "__main__":
    main()
