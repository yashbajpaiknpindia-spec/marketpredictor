from __future__ import annotations

"""MarketPredictor UltraScalp v1

Event-driven, very-short-horizon scalper research engine.

Design goals
------------
* No named technical-analysis strategy is required.
* No probability output is used by the execution layer.
* Raw OHLCV + market/sector/VIX context -> event trigger -> edge score -> trade.
* Long/short symmetry.
* Next-minute-open execution.
* Fast thesis-failure exits, hard protection, short maximum holding time.
* Conservative OHLC ambiguity: stop is assumed to win if stop and target touch
  in the same bar.

This module is research-only. It does not place real orders.
"""

from dataclasses import dataclass, asdict
from typing import Dict, Iterable, Optional, Tuple
import math
import numpy as np
import pandas as pd

try:
    from sklearn.ensemble import HistGradientBoostingRegressor
except Exception:  # pragma: no cover
    HistGradientBoostingRegressor = None


@dataclass(frozen=True)
class UltraScalpConfig:
    # Execution / economics
    target_pct: float = 0.25
    hard_stop_pct: float = 0.10
    max_hold_bars: int = 5
    fast_failure_bars: int = 2
    fast_failure_min_fav_pct: float = 0.02
    roundtrip_cost_pct: float = 0.1063
    stress_cost_pct: float = 0.1663
    slippage_pct: float = 0.03
    # Trigger sensitivity
    volume_z_min: float = 1.25
    range_z_min: float = 1.10
    impulse_min: float = 2.8
    breakout_buffer_pct: float = 0.02
    # Trade hygiene
    cooldown_bars: int = 3
    min_price: float = 50.0
    max_gap_pct_for_entry: float = 4.0
    # Edge model
    min_expected_net_pct: float = 0.04
    min_training_rows: int = 2500
    max_training_rows: int = 100_000
    random_state: int = 42


FEATURES = [
    "ret1_pct", "ret2_pct", "ret3_pct", "accel_pct",
    "range_pct", "body_pct", "close_loc", "upper_wick_pct", "lower_wick_pct",
    "vol_z20", "range_z20", "break_up10", "break_dn10",
    "dist_hi10_pct", "dist_lo10_pct", "dist_vwap_pct",
    "mkt_ret1_pct", "mkt_ret3_pct", "rel_ret1_pct", "rel_ret3_pct",
    "vix_ret1_pct", "sector_ret1_pct", "sector_rel1_pct",
    "tod_sin", "tod_cos", "gap_pct",
]


def _safe_pct(x: pd.Series) -> pd.Series:
    return x.replace([np.inf, -np.inf], np.nan)


def add_features(stock: pd.DataFrame, market: Optional[pd.DataFrame] = None,
                 vix: Optional[pd.DataFrame] = None,
                 sector: Optional[pd.DataFrame] = None) -> pd.DataFrame:
    """Compute causal features using only current/past information."""
    df = stock.copy()
    df = df.sort_index()
    if not isinstance(df.index, pd.DatetimeIndex):
        raise ValueError("stock index must be a DatetimeIndex")
    for c in ("open", "high", "low", "close", "volume"):
        if c not in df:
            raise ValueError(f"missing column: {c}")
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["open", "high", "low", "close"])

    px = df["close"]
    op = df["open"]
    hi = df["high"]
    lo = df["low"]
    rng = (hi - lo).clip(lower=0)
    body = (px - op)
    df["ret1_pct"] = px.pct_change(1) * 100
    df["ret2_pct"] = px.pct_change(2) * 100
    df["ret3_pct"] = px.pct_change(3) * 100
    df["accel_pct"] = df["ret1_pct"] - df["ret2_pct"].div(2)
    df["range_pct"] = rng.div(px.replace(0, np.nan)) * 100
    df["body_pct"] = body.div(px.replace(0, np.nan)) * 100
    df["close_loc"] = ((px - lo) / rng.replace(0, np.nan)).clip(0, 1)
    df["upper_wick_pct"] = ((hi - pd.concat([op, px], axis=1).max(axis=1)) / px.replace(0, np.nan)) * 100
    df["lower_wick_pct"] = ((pd.concat([op, px], axis=1).min(axis=1) - lo) / px.replace(0, np.nan)) * 100

    vol_med = df["volume"].rolling(20, min_periods=10).median()
    vol_mad = (df["volume"] - vol_med).abs().rolling(20, min_periods=10).median()
    df["vol_z20"] = (df["volume"] - vol_med) / (1.4826 * vol_mad.replace(0, np.nan))
    rng_med = df["range_pct"].rolling(20, min_periods=10).median()
    rng_mad = (df["range_pct"] - rng_med).abs().rolling(20, min_periods=10).median()
    df["range_z20"] = (df["range_pct"] - rng_med) / (1.4826 * rng_mad.replace(0, np.nan))

    prev_hi10 = hi.shift(1).rolling(10, min_periods=10).max()
    prev_lo10 = lo.shift(1).rolling(10, min_periods=10).min()
    df["break_up10"] = ((px > prev_hi10 * (1 + 0.0002)).astype(float))
    df["break_dn10"] = ((px < prev_lo10 * (1 - 0.0002)).astype(float))
    df["dist_hi10_pct"] = (px / prev_hi10 - 1) * 100
    df["dist_lo10_pct"] = (px / prev_lo10 - 1) * 100

    pv = (px * df["volume"].fillna(0)).cumsum()
    vv = df["volume"].fillna(0).cumsum().replace(0, np.nan)
    df["dist_vwap_pct"] = (px / (pv / vv) - 1) * 100

    mkt = _align_context(df.index, market, "mkt")
    if mkt is not None:
        df = df.join(mkt, how="left")
    else:
        df["mkt_ret1_pct"] = 0.0
        df["mkt_ret3_pct"] = 0.0
    df["rel_ret1_pct"] = df["ret1_pct"] - df["mkt_ret1_pct"]
    df["rel_ret3_pct"] = df["ret3_pct"] - df["mkt_ret3_pct"]

    vx = _align_context(df.index, vix, "vix")
    if vx is not None:
        df = df.join(vx, how="left")
    else:
        df["vix_ret1_pct"] = 0.0

    sx = _align_context(df.index, sector, "sector")
    if sx is not None:
        df = df.join(sx, how="left")
    else:
        df["sector_ret1_pct"] = 0.0
    df["sector_rel1_pct"] = df["ret1_pct"] - df["sector_ret1_pct"]

    minute = df.index.hour * 60 + df.index.minute
    x = (minute - 75) / max(1, 375 - 75) * math.pi
    df["tod_sin"] = np.sin(x)
    df["tod_cos"] = np.cos(x)

    session_open = df["open"].iloc[0] if len(df) else np.nan
    df["gap_pct"] = 0.0
    if len(df) and np.isfinite(session_open) and session_open:
        df["gap_pct"] = (session_open / df["open"].iloc[0] - 1) * 100

    return df.replace([np.inf, -np.inf], np.nan)


def _align_context(index: pd.DatetimeIndex, context: Optional[pd.DataFrame], prefix: str) -> Optional[pd.DataFrame]:
    if context is None or context.empty:
        return None
    c = context.copy()
    if not isinstance(c.index, pd.DatetimeIndex):
        raise ValueError("context index must be DatetimeIndex")
    c = c.sort_index()
    c = c[~c.index.duplicated(keep="last")].sort_index()
    if "close" not in c:
        return None
    close = pd.to_numeric(c["close"], errors="coerce")
    out = pd.DataFrame(index=c.index)
    out[f"{prefix}_ret1_pct"] = close.pct_change(1) * 100
    out[f"{prefix}_ret3_pct"] = close.pct_change(3) * 100
    if prefix == "vix":
        out[f"{prefix}_ret1_pct"] = close.pct_change(1) * 100
        out = out[[f"{prefix}_ret1_pct"]]
    if prefix == "sector":
        out = out[[f"{prefix}_ret1_pct"]]
    return out.reindex(index, method="ffill")


def event_score(row: pd.Series) -> Tuple[float, int, Dict[str, float]]:
    """Return (score, direction, diagnostics). direction: +1 long, -1 short, 0 none."""
    long_score = 0.0
    short_score = 0.0
    r1 = float(row.get("ret1_pct", 0) or 0)
    r3 = float(row.get("ret3_pct", 0) or 0)
    acc = float(row.get("accel_pct", 0) or 0)
    vz = float(row.get("vol_z20", 0) or 0)
    rz = float(row.get("range_z20", 0) or 0)
    loc = float(row.get("close_loc", 0.5) or 0.5)
    bu = float(row.get("break_up10", 0) or 0)
    bd = float(row.get("break_dn10", 0) or 0)
    rel1 = float(row.get("rel_ret1_pct", 0) or 0)
    rel3 = float(row.get("rel_ret3_pct", 0) or 0)
    m1 = float(row.get("mkt_ret1_pct", 0) or 0)
    sec = float(row.get("sector_ret1_pct", 0) or 0)

    long_score += 1.1 if r1 > 0.12 else 0.0
    long_score += 0.7 if r3 > 0.18 else 0.0
    long_score += 0.8 if acc > 0.03 else 0.0
    long_score += min(1.2, max(0, (vz - 1.0) * 0.55))
    long_score += min(1.0, max(0, (rz - 0.8) * 0.45))
    long_score += 0.8 if loc > 0.72 else 0.0
    long_score += 0.9 if bu > 0.5 else 0.0
    long_score += 0.7 if rel1 > 0.04 else 0.0
    long_score += 0.5 if rel3 > 0.08 else 0.0
    long_score += 0.4 if (m1 > 0 or sec > 0) else 0.0

    short_score += 1.1 if r1 < -0.12 else 0.0
    short_score += 0.7 if r3 < -0.18 else 0.0
    short_score += 0.8 if acc < -0.03 else 0.0
    short_score += min(1.2, max(0, (vz - 1.0) * 0.55))
    short_score += min(1.0, max(0, (rz - 0.8) * 0.45))
    short_score += 0.8 if loc < 0.28 else 0.0
    short_score += 0.9 if bd > 0.5 else 0.0
    short_score += 0.7 if rel1 < -0.04 else 0.0
    short_score += 0.5 if rel3 < -0.08 else 0.0
    short_score += 0.4 if (m1 < 0 or sec < 0) else 0.0

    if long_score >= short_score:
        return long_score, 1, {"long_score": long_score, "short_score": short_score}
    return short_score, -1, {"long_score": long_score, "short_score": short_score}


def build_trigger_table(features: pd.DataFrame, cfg: UltraScalpConfig) -> pd.DataFrame:
    rows = []
    last_signal = -10_000
    for i, (ts, row) in enumerate(features.iterrows()):
        if i < 25:
            continue
        px = float(row.get("close", np.nan))
        if not np.isfinite(px) or px < cfg.min_price:
            continue
        if i - last_signal < cfg.cooldown_bars:
            continue
        score, direction, diag = event_score(row)
        if score < cfg.impulse_min:
            continue
        vz = float(row.get("vol_z20", np.nan))
        rz = float(row.get("range_z20", np.nan))
        if not np.isfinite(vz) or not np.isfinite(rz) or vz < cfg.volume_z_min or rz < cfg.range_z_min:
            continue
        # Fresh move gate: do not chase a move that is already extended.
        if abs(float(row.get("ret3_pct", 0) or 0)) > cfg.max_gap_pct_for_entry:
            continue
        rows.append({"ts": ts, "direction": direction, "event_score": score, **diag})
        last_signal = i
    return pd.DataFrame(rows)


def label_fast_trade(df: pd.DataFrame, i: int, direction: int, cfg: UltraScalpConfig) -> Dict[str, float]:
    """Label a trade entering at next-bar open. Percentages are signed in trade direction."""
    if i + 1 >= len(df):
        return {"outcome_net_pct": np.nan, "gross_pct": np.nan, "exit_bar": np.nan, "exit_reason": "NO_NEXT_BAR"}
    entry = float(df["open"].iloc[i + 1])
    if not np.isfinite(entry) or entry <= 0:
        return {"outcome_net_pct": np.nan, "gross_pct": np.nan, "exit_bar": np.nan, "exit_reason": "BAD_ENTRY"}
    target = entry * (1 + direction * cfg.target_pct / 100)
    stop = entry * (1 - direction * cfg.hard_stop_pct / 100)
    best_fav = 0.0
    for j in range(i + 1, min(len(df), i + 1 + cfg.max_hold_bars)):
        h = float(df["high"].iloc[j]); l = float(df["low"].iloc[j]); c = float(df["close"].iloc[j])
        fav = ((max(h, entry) - entry) / entry * 100) if direction == 1 else ((entry - min(l, entry)) / entry * 100)
        best_fav = max(best_fav, fav)
        if direction == 1:
            hit_stop = l <= stop; hit_target = h >= target
            if hit_stop and hit_target:
                gross = -cfg.hard_stop_pct; reason = "STOP_SAME_BAR"
            elif hit_stop:
                gross = -cfg.hard_stop_pct; reason = "HARD_STOP"
            elif hit_target:
                gross = cfg.target_pct; reason = "TARGET"
            else:
                progress = (c / entry - 1) * 100
                if (j - (i + 1) + 1) >= cfg.fast_failure_bars and progress < cfg.fast_failure_min_fav_pct and best_fav < cfg.fast_failure_min_fav_pct:
                    gross = progress; reason = "THESIS_FAILURE"
                elif j == min(len(df), i + 1 + cfg.max_hold_bars) - 1:
                    gross = progress; reason = "TIMEOUT"
                else:
                    continue
        else:
            hit_stop = h >= stop; hit_target = l <= target
            if hit_stop and hit_target:
                gross = -cfg.hard_stop_pct; reason = "STOP_SAME_BAR"
            elif hit_stop:
                gross = -cfg.hard_stop_pct; reason = "HARD_STOP"
            elif hit_target:
                gross = cfg.target_pct; reason = "TARGET"
            else:
                progress = (entry / c - 1) * 100
                if (j - (i + 1) + 1) >= cfg.fast_failure_bars and progress < cfg.fast_failure_min_fav_pct and best_fav < cfg.fast_failure_min_fav_pct:
                    gross = progress; reason = "THESIS_FAILURE"
                elif j == min(len(df), i + 1 + cfg.max_hold_bars) - 1:
                    gross = progress; reason = "TIMEOUT"
                else:
                    continue
        cost = cfg.roundtrip_cost_pct + cfg.slippage_pct
        return {"outcome_net_pct": gross - cost, "gross_pct": gross, "best_fav_pct": best_fav,
                "exit_bar": j, "exit_reason": reason}
    return {"outcome_net_pct": np.nan, "gross_pct": np.nan, "best_fav_pct": best_fav,
            "exit_bar": np.nan, "exit_reason": "UNRESOLVED"}


class UltraScalpEdgeModel:
    """Fast expected-net-edge scorer; intentionally not a probability model."""
    def __init__(self, cfg: UltraScalpConfig = UltraScalpConfig()):
        self.cfg = cfg
        self.model = None
        self.feature_means = None

    def fit(self, X: pd.DataFrame, y: pd.Series) -> "UltraScalpEdgeModel":
        if HistGradientBoostingRegressor is None:
            raise RuntimeError("scikit-learn is required for the learned edge score")
        data = X[FEATURES].replace([np.inf, -np.inf], np.nan).copy()
        data = data.fillna(0.0)
        valid = y.notna() & np.isfinite(y)
        data = data.loc[valid]
        target = y.loc[valid]
        if len(data) < self.cfg.min_training_rows:
            raise ValueError(f"not enough training rows: {len(data)} < {self.cfg.min_training_rows}")
        if len(data) > self.cfg.max_training_rows:
            rng = np.random.default_rng(self.cfg.random_state)
            take = rng.choice(len(data), self.cfg.max_training_rows, replace=False)
            data = data.iloc[take]
            target = target.iloc[take]
        self.model = HistGradientBoostingRegressor(
            learning_rate=0.055,
            max_iter=180,
            max_leaf_nodes=15,
            min_samples_leaf=120,
            l2_regularization=0.5,
            random_state=self.cfg.random_state,
        )
        self.model.fit(data, target)
        self.feature_means = data.mean()
        return self

    def score(self, X: pd.DataFrame) -> np.ndarray:
        if self.model is None:
            raise RuntimeError("fit() must be called first")
        data = X[FEATURES].replace([np.inf, -np.inf], np.nan).fillna(0.0)
        return self.model.predict(data)


def prepare_training_frame(features: pd.DataFrame, cfg: UltraScalpConfig) -> pd.DataFrame:
    """Create labels for every trigger row without using any future data in features."""
    triggers = build_trigger_table(features, cfg)
    if triggers.empty:
        return triggers
    idx_lookup = {ts: i for i, ts in enumerate(features.index)}
    records = []
    for rec in triggers.to_dict("records"):
        i = idx_lookup[rec["ts"]]
        lab = label_fast_trade(features, i, int(rec["direction"]), cfg)
        base = features.loc[rec["ts"], FEATURES].to_dict()
        base.update(rec)
        base.update(lab)
        records.append(base)
    return pd.DataFrame(records)


def serialize_config(cfg: UltraScalpConfig) -> Dict[str, object]:
    return asdict(cfg)


class UltraScalpRuntime:
    """Incremental single-symbol runtime for fast paper/live-style scoring.

    The runtime keeps only short rolling state. Each new 1-minute bar updates
    the state in bounded time and emits at most one trigger. The learned
    edge model, when attached, is evaluated on one row only.
    """
    def __init__(self, ticker: str, cfg: UltraScalpConfig = UltraScalpConfig()):
        from collections import deque
        self.ticker = ticker
        self.cfg = cfg
        self.closes = deque(maxlen=64)
        self.opens = deque(maxlen=64)
        self.highs = deque(maxlen=64)
        self.lows = deque(maxlen=64)
        self.volumes = deque(maxlen=64)
        self.epochs = deque(maxlen=64)
        self.day_pv = 0.0
        self.day_v = 0.0
        self.model: Optional[UltraScalpEdgeModel] = None
        self.last_trigger_bar = -10_000
        self.bar_count = 0

    def attach_model(self, model: UltraScalpEdgeModel) -> None:
        self.model = model

    def reset_session(self) -> None:
        self.closes.clear(); self.opens.clear(); self.highs.clear(); self.lows.clear(); self.volumes.clear(); self.epochs.clear()
        self.day_pv = 0.0; self.day_v = 0.0; self.bar_count = 0; self.last_trigger_bar = -10_000

    @staticmethod
    def _median_mad(values: np.ndarray) -> Tuple[float, float]:
        if values.size == 0:
            return 0.0, 0.0
        med = float(np.median(values))
        mad = float(np.median(np.abs(values - med)))
        return med, mad

    def update(self, timestamp, open_: float, high: float, low: float, close: float,
               volume: float, market_ret1_pct: float = 0.0, market_ret3_pct: float = 0.0,
               vix_ret1_pct: float = 0.0, sector_ret1_pct: float = 0.0) -> Optional[Dict[str, object]]:
        self.bar_count += 1
        self.epochs.append(timestamp)
        self.opens.append(float(open_)); self.highs.append(float(high)); self.lows.append(float(low))
        self.closes.append(float(close)); self.volumes.append(float(volume))
        self.day_pv += float(close) * max(float(volume), 0.0)
        self.day_v += max(float(volume), 0.0)
        if len(self.closes) < 25:
            return None

        px = self.closes[-1]
        prev1 = self.closes[-2]; prev3 = self.closes[-4]
        r1 = (px / prev1 - 1) * 100 if prev1 else 0.0
        r3 = (px / prev3 - 1) * 100 if prev3 else 0.0
        accel = r1 - r3 / 2.0
        rng = max(self.highs[-1] - self.lows[-1], 0.0)
        range_pct = rng / px * 100 if px else 0.0
        body_pct = (px - self.opens[-1]) / px * 100 if px else 0.0
        close_loc = (px - self.lows[-1]) / rng if rng else 0.5
        upper = (self.highs[-1] - max(self.opens[-1], px)) / px * 100 if px else 0.0
        lower = (min(self.opens[-1], px) - self.lows[-1]) / px * 100 if px else 0.0

        vols = np.asarray(list(self.volumes)[-20:], dtype=float)
        vm, vmad = self._median_mad(vols)
        vol_z = (float(volume) - vm) / (1.4826 * vmad) if vmad > 0 else 0.0
        ranges = np.asarray([
            max(h - l, 0.0) / c * 100 if c else 0.0
            for h, l, c in zip(list(self.highs)[-20:], list(self.lows)[-20:], list(self.closes)[-20:])
        ], dtype=float)
        rm, rmad = self._median_mad(ranges)
        range_z = (range_pct - rm) / (1.4826 * rmad) if rmad > 0 else 0.0

        prev_h10 = max(list(self.highs)[-11:-1])
        prev_l10 = min(list(self.lows)[-11:-1])
        break_up = float(px > prev_h10 * 1.0002)
        break_dn = float(px < prev_l10 * 0.9998)
        vwap = self.day_pv / self.day_v if self.day_v > 0 else px
        dist_vwap = (px / vwap - 1) * 100 if vwap else 0.0

        row = pd.Series({
            "ret1_pct": r1, "ret2_pct": (px / self.closes[-3] - 1) * 100,
            "ret3_pct": r3, "accel_pct": accel, "range_pct": range_pct,
            "body_pct": body_pct, "close_loc": close_loc,
            "upper_wick_pct": upper, "lower_wick_pct": lower,
            "vol_z20": vol_z, "range_z20": range_z,
            "break_up10": break_up, "break_dn10": break_dn,
            "dist_hi10_pct": (px / prev_h10 - 1) * 100,
            "dist_lo10_pct": (px / prev_l10 - 1) * 100,
            "dist_vwap_pct": dist_vwap,
            "mkt_ret1_pct": market_ret1_pct, "mkt_ret3_pct": market_ret3_pct,
            "rel_ret1_pct": r1 - market_ret1_pct, "rel_ret3_pct": r3 - market_ret3_pct,
            "vix_ret1_pct": vix_ret1_pct, "sector_ret1_pct": sector_ret1_pct,
            "sector_rel1_pct": r1 - sector_ret1_pct,
            "tod_sin": 0.0, "tod_cos": 1.0, "gap_pct": 0.0,
        })
        score, direction, diag = event_score(row)
        if self.bar_count - self.last_trigger_bar < self.cfg.cooldown_bars:
            return None
        if score < self.cfg.impulse_min or vol_z < self.cfg.volume_z_min or range_z < self.cfg.range_z_min:
            return None

        edge = None
        if self.model is not None:
            edge = float(self.model.score(pd.DataFrame([row]))[0])
            if edge < self.cfg.min_expected_net_pct:
                return None

        self.last_trigger_bar = self.bar_count
        return {
            "ticker": self.ticker,
            "timestamp": timestamp,
            "direction": "LONG" if direction > 0 else "SHORT",
            "event_score": round(score, 4),
            "edge_score_pct": None if edge is None else round(edge, 5),
            "last_price": px,
            "volume_z": round(vol_z, 3),
            "range_z": round(range_z, 3),
            "diagnostics": diag,
        }
